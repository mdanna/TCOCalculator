define("frmHow", function() {
    return function(controller) {
        function addWidgetsfrmHow() {
            this.setDefaultUnit(voltmx.flex.DP);
            var cmpHeader = new com.hcl.demo.tcocalculator.SimpleHeader({
                "height": "5%",
                "id": "cmpHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxBlack",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "SimpleHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxMain = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "95%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMain.setDefaultUnit(voltmx.flex.DP);
            var flxBody = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBody.setDefaultUnit(voltmx.flex.DP);
            var flxTitle = new voltmx.ui.Label({
                "height": "50dp",
                "id": "flxTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhiteBold150",
                "text": "How HCL Calculates the Results",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblParagraph1 = new voltmx.ui.Label({
                "id": "lblParagraph1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite70",
                "text": "The results of the Volt MX Go TCO calculator are for illustrative purposes only. The results may vary depending on the accuracy and comprehensiveness of the information the customer provides. The online calculator is not a substitute for consulting a qualified business partner or HCL professional. Therefor, to get an accurate quote, customers should work with their HCL sales representative or Business Partner to conduct both an HCL Advisor and MX Studio session. Input form that session and analysis of your Lotus Notes application inventory will enable HCL to provide a fixed price quote for the services involved and the necessary Volt MX Go license.",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblParagraph2 = new voltmx.ui.Label({
                "id": "lblParagraph2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite70",
                "text": "At HCL, we have extensive experience and data about what a representative simple, moderate and comlex app is made up in terms of pages (forms and views), workflows, agents, and integrations. Together, we know what it will take to create a new user experience, reuse the business logic (client and server) and move the dtaa and processes.",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfoBoxes = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100dp",
                "horizontalScrollIndicator": true,
                "id": "flxInfoBoxes",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_HORIZONTAL,
                "skin": "slFSbox",
                "top": "30dp",
                "verticalScrollIndicator": true,
                "width": "570dp",
                "zIndex": 1
            }, {}, {});
            flxInfoBoxes.setDefaultUnit(voltmx.flex.DP);
            var infoBox1 = new com.hcl.demo.tcocalculator.InfoBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "100dp",
                "id": "infoBox1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "170dp",
                "zIndex": 1,
                "overrides": {
                    "InfoBox": {
                        "height": "100dp",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "170dp"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var infoBox2 = new com.hcl.demo.tcocalculator.InfoBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "100dp",
                "id": "infoBox2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "30dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "170dp",
                "zIndex": 1,
                "overrides": {
                    "InfoBox": {
                        "height": "100dp",
                        "left": "30dp",
                        "top": "0dp",
                        "width": "170dp"
                    },
                    "lblInfoBoxTitle": {
                        "text": "Moderate Apps"
                    },
                    "lblLabel1": {
                        "text": "Less than 20 Pages"
                    },
                    "lblLabel2": {
                        "text": "5-10 Workflows"
                    },
                    "lblLabel3": {
                        "text": "3-5 Integrations"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var infoBox3 = new com.hcl.demo.tcocalculator.InfoBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "100dp",
                "id": "infoBox3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "30dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "170dp",
                "zIndex": 1,
                "overrides": {
                    "InfoBox": {
                        "height": "100dp",
                        "left": "30dp",
                        "top": "0dp",
                        "width": "170dp"
                    },
                    "lblInfoBoxTitle": {
                        "text": "Complex Apps"
                    },
                    "lblLabel1": {
                        "text": "More than 20 Pages"
                    },
                    "lblLabel2": {
                        "text": "> 10 Workflows"
                    },
                    "lblLabel3": {
                        "left": "9dp",
                        "text": "> 5 Integrations"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxInfoBoxes.add(infoBox1, infoBox2, infoBox3);
            var lblParagraph3 = new voltmx.ui.Label({
                "id": "lblParagraph3",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite70",
                "text": "The following table shows how Volt MX Go* handles your migration at each stage compared to other low code competitors, highlighting where savings can be achieved. HCL accepts no liability for damage of any kind that is direct or indirect result of your use of the TCO calculator, or for actions or decisions based on the calculator savings in the full value report or this table.",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxComparison = new voltmx.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "300dp",
                "id": "flxComparison",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "181dp",
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "75dp",
                "width": "97%",
                "zIndex": 1
            }, {}, {});
            flxComparison.setDefaultUnit(voltmx.flex.DP);
            var flxComparisonContent = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxComparisonContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxComparisonContent.setDefaultUnit(voltmx.flex.DP);
            var flxComparisonHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxComparisonHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxComparisonAlt",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeader.setDefaultUnit(voltmx.flex.DP);
            var flxComparisonHeaderSteps = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxComparisonHeaderSteps",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeaderSteps.setDefaultUnit(voltmx.flex.DP);
            var lblComparisonHeaderSteps = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComparisonHeaderSteps",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite100",
                "text": "Steps",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonHeaderSteps.add(lblComparisonHeaderSteps);
            var flxComparisonHeaderPlan = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxComparisonHeaderPlan",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeaderPlan.setDefaultUnit(voltmx.flex.DP);
            var lblComparisonHeaderPlan = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComparisonHeaderPlan",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite100",
                "text": "Analyze & Plan",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonHeaderPlan.add(lblComparisonHeaderPlan);
            var flxComparisonHeaderMigrate = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxComparisonHeaderMigrate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "26%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeaderMigrate.setDefaultUnit(voltmx.flex.DP);
            var lblComparisonHeaderMigrate = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComparisonHeaderMigrate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite100",
                "text": "Migrate",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonHeaderMigrate.add(lblComparisonHeaderMigrate);
            var flxComparisonHeaderTest = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxComparisonHeaderTest",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeaderTest.setDefaultUnit(voltmx.flex.DP);
            var lblComparisonHeaderTest = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComparisonHeaderTest",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite100",
                "text": "Test & Publish",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonHeaderTest.add(lblComparisonHeaderTest);
            var flxComparisonHeaderManage = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxComparisonHeaderManage",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonHeaderManage.setDefaultUnit(voltmx.flex.DP);
            var lblComparisonHeaderManage = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComparisonHeaderManage",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite100",
                "text": "Manage",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonHeaderManage.add(lblComparisonHeaderManage);
            flxComparisonHeader.add(flxComparisonHeaderSteps, flxComparisonHeaderPlan, flxComparisonHeaderMigrate, flxComparisonHeaderTest, flxComparisonHeaderManage);
            var flxComparisonLine1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxComparisonLine1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1.setDefaultUnit(voltmx.flex.DP);
            var flxComparisonLine1Cell1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine1Cell1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1Cell1.setDefaultUnit(voltmx.flex.DP);
            var lblVoltMXGo = new voltmx.ui.Label({
                "id": "lblVoltMXGo",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite80",
                "text": "Volt MX Go",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonLine1Cell1.add(lblVoltMXGo);
            var flxComparisonLine1Cell2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine1Cell2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1Cell2.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine1 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Reuse existing data model, views and forms"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine2 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Use new common components, UX templates and branding"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine1Cell2.add(comparisonLine1, comparisonLine2);
            var flxComparisonLine1Cell3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine1Cell3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "26%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1Cell3.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine3 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "NoSQL DB used, so deta is moved (not migrated)"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine4 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine4",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Specific feautures supported +"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine5 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine5",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "@Formula & LotusScript compatible (as native JavaScript) +"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine6 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine6",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Processes run with limited changes +"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine1Cell3.add(comparisonLine3, comparisonLine4, comparisonLine5, comparisonLine6);
            var flxComparisonLine1Cell4 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine1Cell4",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1Cell4.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine7 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine7",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Same data model, same business logic, new UX - limited testing required"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine8 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine8",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Use of MX Go test automation and CI/CD"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine9 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine9",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "New apps can run concurrently with existing apps without coding"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine1Cell4.add(comparisonLine7, comparisonLine8, comparisonLine9);
            var flxComparisonLine1Cell5 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine1Cell5",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine1Cell5.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine10 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine10",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "App-wide Admin tool"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine1Cell5.add(comparisonLine10);
            flxComparisonLine1.add(flxComparisonLine1Cell1, flxComparisonLine1Cell2, flxComparisonLine1Cell3, flxComparisonLine1Cell4, flxComparisonLine1Cell5);
            var flxDivider1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10dp",
                "id": "flxDivider1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxDivider1.setDefaultUnit(voltmx.flex.DP);
            flxDivider1.add();
            var flxComparisonLine2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxComparisonLine2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxComparisonAlt",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2.setDefaultUnit(voltmx.flex.DP);
            var flxComparisonLine2Cell1 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine2Cell1",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2Cell1.setDefaultUnit(voltmx.flex.DP);
            var lblCompetitor = new voltmx.ui.Label({
                "id": "lblCompetitor",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite80",
                "text": "Low-code Competitor",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComparisonLine2Cell1.add(lblCompetitor);
            var flxComparisonLine2Cell2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine2Cell2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2Cell2.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine11 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine11",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Create a new data model"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine12 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine12",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Create new forms and workflows"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine13 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine13",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Create new code for the business logic and integrations"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine14 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine14",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Create new common components"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine2Cell2.add(comparisonLine11, comparisonLine12, comparisonLine13, comparisonLine14);
            var flxComparisonLine2Cell3 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine2Cell3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "26%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2Cell3.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine15 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine15",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "MS SQL DB used, so data must be normalized and migrated"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine16 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine16",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Code is used to work around specific advanced features"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine17 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine17",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Business Logic must be re-writeen in proprietary Language and JavaScript"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine18 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine18",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Processes must be rewritten from scratch"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine2Cell3.add(comparisonLine15, comparisonLine16, comparisonLine17, comparisonLine18);
            var flxComparisonLine2Cell4 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine2Cell4",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2Cell4.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine19 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine19",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Brand new app requires extensive testing"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var comparisonLine20 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine20",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Isolated from existing apps for a test, data consistency standpoint or requires coding"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine2Cell4.add(comparisonLine19, comparisonLine20);
            var flxComparisonLine2Cell5 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxComparisonLine2Cell5",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {}, {});
            flxComparisonLine2Cell5.setDefaultUnit(voltmx.flex.DP);
            var comparisonLine21 = new com.hcl.demo.tcocalculator.ComparisonLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "comparisonLine21",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblLabel": {
                        "text": "Every app is isolated requiring more admin support"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisonLine2Cell5.add(comparisonLine21);
            flxComparisonLine2.add(flxComparisonLine2Cell1, flxComparisonLine2Cell2, flxComparisonLine2Cell3, flxComparisonLine2Cell4, flxComparisonLine2Cell5);
            var flxDivider2 = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10dp",
                "id": "flxDivider2",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxComparisonAlt",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxDivider2.setDefaultUnit(voltmx.flex.DP);
            flxDivider2.add();
            flxComparisonContent.add(flxComparisonHeader, flxComparisonLine1, flxDivider1, flxComparisonLine2, flxDivider2);
            flxComparison.add(flxComparisonContent);
            var lblParagraph4 = new voltmx.ui.Label({
                "id": "lblParagraph4",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite70",
                "text": "* Disclaimer: HCL's statements regarding its plans, directions, and intent are subject to change or withdrawal without notice and at HCL's sole discretion. Information regarding potential future products is intended to outline our general product direction and it should not be relied on in making a purchasing decision. The information mentioned regarding potential future products is not a commitment, promise, or legal obligation to deliver any material, code or functionality. Information about potential future products may not be incomporated into any contract. The development, release, and timing of any future features or functionality described for our products remains at our sole discretion. Performance is based on measurements and projections using standard HCL benchmarks in a controlled environment. The actual throughput or performance that any user will experience will vary depending upon many factors, including considerations such as the amount of multiprogramming in the user's job stream, the I/O configuration, the storage configuration, and the workload processed. Therefore, no assurance can be given that an individual user will achieve results like those stated here.",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblParagraph5 = new voltmx.ui.Label({
                "id": "lblParagraph5",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite70",
                "text": "Definitions:",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var definitionsLine1 = new com.hcl.demo.tcocalculator.DefinitionsLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "definitionsLine1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "overrides": {
                    "lblCircle": {
                        "width": "5dp"
                    },
                    "lblDefinition": {
                        "text": "Any web or mobile screen that allows for entering, modifying data, or presenting a data grid."
                    },
                    "lblTitle": {
                        "left": "5dp",
                        "text": "Pages:"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var definitionsLine2 = new com.hcl.demo.tcocalculator.DefinitionsLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "definitionsLine2",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "overrides": {
                    "DefinitionsLine": {
                        "top": "5dp"
                    },
                    "lblCircle": {
                        "width": "5dp"
                    },
                    "lblDefinition": {
                        "text": "A business or approval process that allows requests or data to move through different stages."
                    },
                    "lblTitle": {
                        "left": "5dp",
                        "text": "Workflows:"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var definitionsLine3 = new com.hcl.demo.tcocalculator.DefinitionsLine({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "id": "definitionsLine3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "overrides": {
                    "DefinitionsLine": {
                        "bottom": "20dp",
                        "top": "5dp"
                    },
                    "lblCircle": {
                        "width": "5dp"
                    },
                    "lblDefinition": {
                        "text": "Any integration with an external system or 3rd party enterprise system or SaaS solution such as SAP, Oracle, or Salesforce."
                    },
                    "lblTitle": {
                        "left": "5dp",
                        "text": "Integrations:"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBody.add(flxTitle, lblParagraph1, lblParagraph2, flxInfoBoxes, lblParagraph3, flxComparison, lblParagraph4, lblParagraph5, definitionsLine1, definitionsLine2, definitionsLine3);
            flxMain.add(flxBody);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoBoxes": {
                        "width": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "infoBox1": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": [],
                        "instanceId": "infoBox1"
                    },
                    "infoBox2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "infoBox3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxComparison": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxComparisonContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoBoxes": {
                        "width": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    },
                    "infoBox1": {
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": [],
                        "instanceId": "infoBox1"
                    },
                    "infoBox2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "infoBox3": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "flxComparison": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxComparisonContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxComparison": {
                        "layoutType": voltmx.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "1000dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxComparisonContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxComparisonHeader": {
                        "segmentProps": []
                    },
                    "flxComparisonHeaderSteps": {
                        "segmentProps": []
                    },
                    "lblComparisonHeaderSteps": {
                        "segmentProps": []
                    },
                    "flxComparisonHeaderPlan": {
                        "segmentProps": []
                    },
                    "lblComparisonHeaderPlan": {
                        "segmentProps": []
                    },
                    "flxComparisonHeaderMigrate": {
                        "segmentProps": []
                    },
                    "lblComparisonHeaderMigrate": {
                        "segmentProps": []
                    },
                    "flxComparisonHeaderTest": {
                        "segmentProps": []
                    },
                    "lblComparisonHeaderTest": {
                        "segmentProps": []
                    },
                    "flxComparisonHeaderManage": {
                        "segmentProps": []
                    },
                    "lblComparisonHeaderManage": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1Cell1": {
                        "segmentProps": []
                    },
                    "lblVoltMXGo": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1Cell2": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1Cell3": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1Cell4": {
                        "segmentProps": []
                    },
                    "flxComparisonLine1Cell5": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2Cell1": {
                        "segmentProps": []
                    },
                    "lblCompetitor": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2Cell2": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2Cell3": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2Cell4": {
                        "segmentProps": []
                    },
                    "flxComparisonLine2Cell5": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "cmpHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "infoBox1": {
                    "height": "100dp",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "170dp"
                },
                "infoBox2": {
                    "height": "100dp",
                    "left": "30dp",
                    "top": "0dp",
                    "width": "170dp"
                },
                "infoBox2.lblInfoBoxTitle": {
                    "text": "Moderate Apps"
                },
                "infoBox2.lblLabel1": {
                    "text": "Less than 20 Pages"
                },
                "infoBox2.lblLabel2": {
                    "text": "5-10 Workflows"
                },
                "infoBox2.lblLabel3": {
                    "text": "3-5 Integrations"
                },
                "infoBox3": {
                    "height": "100dp",
                    "left": "30dp",
                    "top": "0dp",
                    "width": "170dp"
                },
                "infoBox3.lblInfoBoxTitle": {
                    "text": "Complex Apps"
                },
                "infoBox3.lblLabel1": {
                    "text": "More than 20 Pages"
                },
                "infoBox3.lblLabel2": {
                    "text": "> 10 Workflows"
                },
                "infoBox3.lblLabel3": {
                    "left": "9dp",
                    "text": "> 5 Integrations"
                },
                "comparisonLine1.lblLabel": {
                    "text": "Reuse existing data model, views and forms"
                },
                "comparisonLine2.lblLabel": {
                    "text": "Use new common components, UX templates and branding"
                },
                "comparisonLine3.lblLabel": {
                    "text": "NoSQL DB used, so deta is moved (not migrated)"
                },
                "comparisonLine4.lblLabel": {
                    "text": "Specific feautures supported +"
                },
                "comparisonLine5.lblLabel": {
                    "text": "@Formula & LotusScript compatible (as native JavaScript) +"
                },
                "comparisonLine6.lblLabel": {
                    "text": "Processes run with limited changes +"
                },
                "comparisonLine7.lblLabel": {
                    "text": "Same data model, same business logic, new UX - limited testing required"
                },
                "comparisonLine8.lblLabel": {
                    "text": "Use of MX Go test automation and CI/CD"
                },
                "comparisonLine9.lblLabel": {
                    "text": "New apps can run concurrently with existing apps without coding"
                },
                "comparisonLine10.lblLabel": {
                    "text": "App-wide Admin tool"
                },
                "comparisonLine11.lblLabel": {
                    "text": "Create a new data model"
                },
                "comparisonLine12.lblLabel": {
                    "text": "Create new forms and workflows"
                },
                "comparisonLine13.lblLabel": {
                    "text": "Create new code for the business logic and integrations"
                },
                "comparisonLine14.lblLabel": {
                    "text": "Create new common components"
                },
                "comparisonLine15.lblLabel": {
                    "text": "MS SQL DB used, so data must be normalized and migrated"
                },
                "comparisonLine16.lblLabel": {
                    "text": "Code is used to work around specific advanced features"
                },
                "comparisonLine17.lblLabel": {
                    "text": "Business Logic must be re-writeen in proprietary Language and JavaScript"
                },
                "comparisonLine18.lblLabel": {
                    "text": "Processes must be rewritten from scratch"
                },
                "comparisonLine19.lblLabel": {
                    "text": "Brand new app requires extensive testing"
                },
                "comparisonLine20.lblLabel": {
                    "text": "Isolated from existing apps for a test, data consistency standpoint or requires coding"
                },
                "comparisonLine21.lblLabel": {
                    "text": "Every app is isolated requiring more admin support"
                },
                "definitionsLine1.lblCircle": {
                    "width": "5dp"
                },
                "definitionsLine1.lblDefinition": {
                    "text": "Any web or mobile screen that allows for entering, modifying data, or presenting a data grid."
                },
                "definitionsLine1.lblTitle": {
                    "left": "5dp",
                    "text": "Pages:"
                },
                "definitionsLine2": {
                    "top": "5dp"
                },
                "definitionsLine2.lblCircle": {
                    "width": "5dp"
                },
                "definitionsLine2.lblDefinition": {
                    "text": "A business or approval process that allows requests or data to move through different stages."
                },
                "definitionsLine2.lblTitle": {
                    "left": "5dp",
                    "text": "Workflows:"
                },
                "definitionsLine3": {
                    "bottom": "20dp",
                    "top": "5dp"
                },
                "definitionsLine3.lblCircle": {
                    "width": "5dp"
                },
                "definitionsLine3.lblDefinition": {
                    "text": "Any integration with an external system or 3rd party enterprise system or SaaS solution such as SAP, Oracle, or Salesforce."
                },
                "definitionsLine3.lblTitle": {
                    "left": "5dp",
                    "text": "Integrations:"
                }
            }
            this.add(cmpHeader, flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmHow,
            "enabledForIdleTimeout": false,
            "id": "frmHow",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGradient",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});