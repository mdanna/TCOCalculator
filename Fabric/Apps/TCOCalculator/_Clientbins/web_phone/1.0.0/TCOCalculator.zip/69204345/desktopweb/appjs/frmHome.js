define("frmHome", function() {
    return function(controller) {
        function addWidgetsfrmHome() {
            this.setDefaultUnit(voltmx.flex.DP);
            var cmpHeader = new com.hcl.demo.tcocalculator.SimpleHeader({
                "height": "5%",
                "id": "cmpHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxBlack",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "SimpleHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxMain = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "95%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%"
            }, {}, {});
            flxMain.setDefaultUnit(voltmx.flex.DP);
            var flxBody = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "392dp",
                "maxWidth": "1000dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "248dp",
                "width": "80%",
                "zIndex": 1
            }, {}, {});
            flxBody.setDefaultUnit(voltmx.flex.DP);
            var flxTitle = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxTitle.setDefaultUnit(voltmx.flex.DP);
            var lblTitle = new voltmx.ui.Label({
                "id": "lblTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhiteBold150",
                "text": "HCL Volt MX Go: Total Cost of Ownership Calculator",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSubtitle = new voltmx.ui.Label({
                "id": "lblSubtitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDirtyWhiteNormal80",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_home_info\")",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblTitle, lblSubtitle);
            var flxContent = new voltmx.ui.FlexContainer({
                "bottom": "20dp",
                "clipBounds": true,
                "height": "83%",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "minWidth": "850dp",
                "isModalContainer": false,
                "skin": "sknFlxGradient",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContent.setDefaultUnit(voltmx.flex.DP);
            var flxData = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "30dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "600dp",
                "horizontalScrollIndicator": true,
                "id": "flxData",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "30dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "30dp",
                "verticalScrollIndicator": true,
                "width": "25%",
                "zIndex": 1
            }, {}, {});
            flxData.setDefaultUnit(voltmx.flex.DP);
            var fieldHowManyApps = new com.hcl.demo.tcocalculator.StandardEditField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldHowManyApps",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "txtField": {
                        "placeholder": "Enter the number of applications"
                    },
                    "StandardEditField": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var fieldHowManyUsers = new com.hcl.demo.tcocalculator.StandardEditField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldHowManyUsers",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblLabel": {
                        "text": "How many users need to access the apps? *"
                    },
                    "txtField": {
                        "placeholder": "Enter the number of users"
                    },
                    "StandardEditField": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var fieldNumPerc = new com.hcl.demo.tcocalculator.StandardNumPerc({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldNumPerc",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblLabel": {
                        "text": "How many of the apps would you categorize as simple, moderate and complex?  *"
                    },
                    "StandardNumPerc": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            fieldNumPerc.selection = "none";
            var flxNumPerc = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNumPerc",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%"
            }, {}, {});
            flxNumPerc.setDefaultUnit(voltmx.flex.DP);
            var fieldSimple = new com.hcl.demo.tcocalculator.StandardEditField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldSimple",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblLabel": {
                        "text": "Simple (e.g. Leave Requests, Document Approvals)"
                    },
                    "txtField": {
                        "placeholder": "Number simple applications"
                    },
                    "StandardEditField": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var fieldModerate = new com.hcl.demo.tcocalculator.StandardEditField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldModerate",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblLabel": {
                        "text": "Moderate (e.g. Expense Management, Timesheet)"
                    },
                    "txtField": {
                        "placeholder": "Number moderate applications"
                    },
                    "StandardEditField": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var fieldComplex = new com.hcl.demo.tcocalculator.StandardEditField({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "id": "fieldComplex",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "lblLabel": {
                        "text": "Complex (e.g. Claims Handling, Loan Approvals)"
                    },
                    "txtField": {
                        "placeholder": "Number complex applications"
                    },
                    "StandardEditField": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCalculate = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxCalculate",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxVioletFull",
                "top": "30dp",
                "width": "99%",
                "zIndex": 1
            }, {}, {});
            flxCalculate.setDefaultUnit(voltmx.flex.DP);
            var lblCalculate = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblCalculate",
                "isVisible": true,
                "skin": "sknLblBlack70",
                "text": "CALCULATE",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCalculate.add(lblCalculate);
            var lblReset = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "20dp",
                "id": "lblReset",
                "isVisible": true,
                "skin": "sknLblWhite80Underlined",
                "text": "Reset Calculator",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNumPerc.add(fieldSimple, fieldModerate, fieldComplex, flxCalculate, lblReset);
            flxData.add(fieldHowManyApps, fieldHowManyUsers, fieldNumPerc, flxNumPerc);
            var flxResults = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "30dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxResults",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "pagingEnabled": false,
                "right": "30dp",
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "CopyslFbox0je2486ce516d4c",
                "top": "30dp",
                "verticalScrollIndicator": true,
                "width": "65%",
                "zIndex": 1
            }, {}, {});
            flxResults.setDefaultUnit(voltmx.flex.DP);
            var flxResultsHeader = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxResultsHeader",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%"
            }, {}, {});
            flxResultsHeader.setDefaultUnit(voltmx.flex.DP);
            var lblYourSavings = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "50dp",
                "id": "lblYourSavings",
                "isVisible": true,
                "skin": "sknLblWhite100",
                "text": "Your Savings with Volt MX Go (Year 1)",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSavings = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSavings",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSavings.setDefaultUnit(voltmx.flex.DP);
            var flxOverallSavings = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "35%",
                "clipBounds": true,
                "id": "flxOverallSavings",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "169dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1
            }, {}, {});
            flxOverallSavings.setDefaultUnit(voltmx.flex.DP);
            var lblOverallSavingsValue = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblOverallSavingsValue",
                "isVisible": true,
                "skin": "sknLblViolet250",
                "text": "--%",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverallSavings = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "30dp",
                "id": "lblOverallSavings",
                "isVisible": true,
                "left": "96dp",
                "skin": "sknLblWhite100",
                "text": "Overall Savings",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOverallSavings.add(lblOverallSavingsValue, lblOverallSavings);
            var flxTotalSavings = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "65%",
                "clipBounds": true,
                "id": "flxTotalSavings",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "330dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1
            }, {}, {});
            flxTotalSavings.setDefaultUnit(voltmx.flex.DP);
            var lblTotalSavingsValue = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblTotalSavingsValue",
                "isVisible": true,
                "skin": "sknLblViolet250",
                "text": "$--",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalSavings = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "30dp",
                "id": "lblTotalSavings",
                "isVisible": true,
                "left": "96dp",
                "skin": "sknLblWhite100",
                "text": "Total Savings",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalSavings.add(lblTotalSavingsValue, lblTotalSavings);
            flxSavings.add(flxOverallSavings, flxTotalSavings);
            flxResultsHeader.add(lblYourSavings, flxSavings);
            var flxResultsInfo = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "90%",
                "id": "flxResultsInfo",
                "isVisible": false,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxResultsInfo.setDefaultUnit(voltmx.flex.DP);
            var lblCompared = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "50dp",
                "id": "lblCompared",
                "isVisible": true,
                "skin": "sknLblWhite120",
                "text": "compared to Mendix, Outsystems and PowerApps",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeeFullReport = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSeeFullReport",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxVioletFull",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {}, {});
            flxSeeFullReport.setDefaultUnit(voltmx.flex.DP);
            var lblSeeFullReport = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblSeeFullReport",
                "isVisible": true,
                "skin": "sknLblBlack70",
                "text": "SEE FULL REPORT",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeeFullReport.add(lblSeeFullReport);
            var lblUnlock = new voltmx.ui.Label({
                "id": "lblUnlock",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDirtyWhiteNormal80",
                "text": "Unlock the full report to get a 3- and 5- year total cost ownership comparison",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeeHow = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSeeHow",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "25dp",
                "width": "300dp",
                "zIndex": 1
            }, {}, {});
            flxSeeHow.setDefaultUnit(voltmx.flex.DP);
            var lblSeeHow = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblSeeHow",
                "isVisible": true,
                "skin": "sknLblViolet70",
                "text": "SEE HOW WE CALCULATED RESULTS",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeeHow.add(lblSeeHow);
            var lblDisclaimer = new voltmx.ui.Label({
                "centerX": "50%",
                "id": "lblDisclaimer",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblDirtyWhiteNormal80",
                "i18n_text": "voltmx.i18n.getLocalizedString(\"i18n_results_disclaimer\")",
                "top": "20dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSpacer = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxSpacer",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxSpacer.setDefaultUnit(voltmx.flex.DP);
            flxSpacer.add();
            flxResultsInfo.add(lblCompared, flxSeeFullReport, lblUnlock, flxSeeHow, lblDisclaimer, flxSpacer);
            flxResults.add(flxResultsHeader, flxResultsInfo);
            flxContent.add(flxData, flxResults);
            flxBody.add(flxTitle, flxContent);
            flxMain.add(flxBody);
            var popupContactInfo = new com.hcl.demo.tcocalculator.ContactInfo({
                "height": "100%",
                "id": "popupContactInfo",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "ContactInfo": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var popupAlert = new com.hcl.demo.tcocalculator.SimpleAlert({
                "height": "100%",
                "id": "popupAlert",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "SimpleAlert": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblTitle": {
                        "segmentProps": []
                    },
                    "lblSubtitle": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "flxData": {
                        "segmentProps": []
                    },
                    "flxResults": {
                        "segmentProps": []
                    },
                    "lblUnlock": {
                        "segmentProps": []
                    },
                    "lblDisclaimer": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxContent": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "cmpHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldHowManyApps": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldHowManyUsers": {
                    "label": "How many users need to access the apps? *",
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldNumPerc": {
                    "label": "How many of the apps would you categorize as simple, moderate and complex?  *",
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldSimple": {
                    "label": "Simple (e.g. Leave Requests, Document Approvals)",
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldModerate": {
                    "label": "Moderate (e.g. Expense Management, Timesheet)",
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "fieldComplex": {
                    "label": "Complex (e.g. Claims Handling, Loan Approvals)",
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "popupContactInfo": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "popupAlert": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(cmpHeader, flxMain, popupContactInfo, popupAlert);
        };
        return [{
            "addWidgets": addWidgetsfrmHome,
            "enabledForIdleTimeout": false,
            "id": "frmHome",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGradient",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});