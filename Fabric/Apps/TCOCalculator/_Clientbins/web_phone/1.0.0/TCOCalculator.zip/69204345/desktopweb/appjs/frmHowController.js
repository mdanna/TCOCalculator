define("userfrmHowController", {
    onViewCreated() {
        this.view.init = () => {
            this.view.flxComparisonContent.doLayout = () => {
                this.view.flxComparison.height = `${this.view.flxComparisonContent.frame.height + 30}dp`;
            };
            this.view.cmpHeader.onTouchEnd = () => new voltmx.mvc.Navigation('frmHome').navigate();
        };
    }
});
define("frmHowControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmHowController", ["userfrmHowController", "frmHowControllerActions"], function() {
    var controller = require("userfrmHowController");
    var controllerActions = ["frmHowControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
