define('applicationController',{
    appInit: function(params) {
        skinsInit();
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.CheckBox", "CheckBox", "CheckBoxController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "CheckBox",
            "name": "com.hcl.demo.tcocalculator.CheckBox"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.ComparisonBox", "ComparisonBox", "ComparisonBoxController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "ComparisonBox",
            "name": "com.hcl.demo.tcocalculator.ComparisonBox"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.ComparisonLine", "ComparisonLine", "ComparisonLineController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "ComparisonLine",
            "name": "com.hcl.demo.tcocalculator.ComparisonLine"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.ContactInfo", "ContactInfo", "ContactInfoController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "ContactInfo",
            "name": "com.hcl.demo.tcocalculator.ContactInfo"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.ContactInfoEditField", "ContactInfoEditField", "ContactInfoEditFieldController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "ContactInfoEditField",
            "name": "com.hcl.demo.tcocalculator.ContactInfoEditField"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.DefinitionsLine", "DefinitionsLine", "DefinitionsLineController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "DefinitionsLine",
            "name": "com.hcl.demo.tcocalculator.DefinitionsLine"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.InfoBox", "InfoBox", "InfoBoxController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "InfoBox",
            "name": "com.hcl.demo.tcocalculator.InfoBox"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.MobileHeader", "MobileHeader", "MobileHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "MobileHeader",
            "name": "com.hcl.demo.tcocalculator.MobileHeader"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.SimpleAlert", "SimpleAlert", "SimpleAlertController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "SimpleAlert",
            "name": "com.hcl.demo.tcocalculator.SimpleAlert"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.SimpleHeader", "SimpleHeader", "SimpleHeaderController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "SimpleHeader",
            "name": "com.hcl.demo.tcocalculator.SimpleHeader"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.StandardEditField", "StandardEditField", "StandardEditFieldController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "StandardEditField",
            "name": "com.hcl.demo.tcocalculator.StandardEditField"
        });
        voltmx.mvc.registry.add("com.hcl.demo.tcocalculator.StandardNumPerc", "StandardNumPerc", "StandardNumPercController");
        voltmx.application.registerMaster({
            "namespace": "com.hcl.demo.tcocalculator",
            "classname": "StandardNumPerc",
            "name": "com.hcl.demo.tcocalculator.StandardNumPerc"
        });
        voltmx.mvc.registry.add("frmFullReport", "frmFullReport", "frmFullReportController");
        voltmx.mvc.registry.add("frmHome", "frmHome", "frmHomeController");
        voltmx.mvc.registry.add("frmHow", "frmHow", "frmHowController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new voltmx.mvc.Navigation("frmHome").navigate();
    }
});

define("com/hcl/demo/tcocalculator/CheckBox/userCheckBoxController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.onClick = () => {
                        this.selected = !this.selected;
                        this.onSelect(this.selected);
                    };
                    this.initDone = true;
                }
                this.view.lblChecked.isVisible = this.selected;
                this.view.lblUnchecked.isVisible = !this.selected;
            };
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            defineGetter(this, 'selected', () => {
                return this._selected;
            });
            defineSetter(this, 'selected', (value) => {
                this._selected = value;
                try {
                    this.view.lblChecked.isVisible = value;
                    this.view.lblUnchecked.isVisible = !value;
                } catch (ignore) {}
            });
        },
        onSelect() {}
    };
});
define("com/hcl/demo/tcocalculator/CheckBox/CheckBoxControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/CheckBox/CheckBoxController", ["com/hcl/demo/tcocalculator/CheckBox/userCheckBoxController", "com/hcl/demo/tcocalculator/CheckBox/CheckBoxControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/CheckBox/userCheckBoxController");
    var actions = require("com/hcl/demo/tcocalculator/CheckBox/CheckBoxControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.lblText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblText.text;
        });
        defineSetter(this, "skinText", function(val) {
            this.view.lblText.skin = val;
        });
        defineGetter(this, "skinText", function() {
            return this.view.lblText.skin;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/CheckBox/CheckBox',[],function() {
    return function(controller) {
        var CheckBox = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "30dp",
            "id": "CheckBox",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "CheckBox"), extendConfig({}, controller.args[1], "CheckBox"), extendConfig({}, controller.args[2], "CheckBox"));
        CheckBox.setDefaultUnit(voltmx.flex.DP);
        var lblChecked = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblChecked",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "c",
            "textStyle": {},
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblChecked"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblChecked"), extendConfig({}, controller.args[2], "lblChecked"));
        var lblUnchecked = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblUnchecked",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "b",
            "textStyle": {},
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblUnchecked"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUnchecked"), extendConfig({}, controller.args[2], "lblUnchecked"));
        var lblText = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "100%",
            "id": "lblText",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknMediumBlack70",
            "text": "Remember Me",
            "textStyle": {},
            "width": "95%",
            "zIndex": 1
        }, controller.args[0], "lblText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblText"), extendConfig({}, controller.args[2], "lblText"));
        CheckBox.add(lblChecked, lblUnchecked, lblText);
        return CheckBox;
    }
})
;
define('com/hcl/demo/tcocalculator/CheckBox/CheckBoxConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "skinText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selected",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onSelect"]
    }
});

define("com/hcl/demo/tcocalculator/ComparisonBox/userComparisonBoxController", [],function() {
    return {
        setData(costMXGo, costCompetitor, numApps) {
            this.view.lblTotalMXGoCost.text = `$${costMXGo.toFixed(1)}K`;
            this.view.lblTotalCompetitorCost.text = `$${costCompetitor.toFixed(1)}K`;
            this.view.lblTotalSavings.text = `$${(costCompetitor - costMXGo).toFixed(1)}K`;
            this.view.lblTotalSaved.text = `${(((costCompetitor - costMXGo) / costCompetitor) * 100).toFixed(1)}%`;
            this.view.lblSavingsPerApp.text = `$${((costCompetitor - costMXGo) / numApps).toFixed(1)}K`;
        }
    };
});
define("com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBoxControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBoxController", ["com/hcl/demo/tcocalculator/ComparisonBox/userComparisonBoxController", "com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBoxControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/ComparisonBox/userComparisonBoxController");
    var actions = require("com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBoxControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBox',[],function() {
    return function(controller) {
        var ComparisonBox = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "425dp",
            "id": "ComparisonBox",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxVioletTransparent",
            "top": "0dp",
            "width": "30%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ComparisonBox"), extendConfig({}, controller.args[1], "ComparisonBox"), extendConfig({}, controller.args[2], "ComparisonBox"));
        ComparisonBox.setDefaultUnit(voltmx.flex.DP);
        var lblYear = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "80dp",
            "id": "lblYear",
            "isVisible": true,
            "skin": "sknLblVioletBold170",
            "text": "Year 1",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblYear"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblYear"), extendConfig({}, controller.args[2], "lblYear"));
        var lblTotalMXGoCostLabel = new voltmx.ui.Label(extendConfig({
            "height": "15dp",
            "id": "lblTotalMXGoCostLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLightBlue70",
            "text": "TOTAL MX GO COST",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalMXGoCostLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalMXGoCostLabel"), extendConfig({}, controller.args[2], "lblTotalMXGoCostLabel"));
        var lblTotalMXGoCost = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lblTotalMXGoCost",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite150",
            "text": "$99K",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalMXGoCost"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalMXGoCost"), extendConfig({}, controller.args[2], "lblTotalMXGoCost"));
        var lblTotalCompetitorCostLabel = new voltmx.ui.Label(extendConfig({
            "height": "15dp",
            "id": "lblTotalCompetitorCostLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLightBlue70",
            "text": "TOTAL COMPETITOR COST",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalCompetitorCostLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalCompetitorCostLabel"), extendConfig({}, controller.args[2], "lblTotalCompetitorCostLabel"));
        var lblTotalCompetitorCost = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lblTotalCompetitorCost",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite150",
            "text": "$199K",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalCompetitorCost"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalCompetitorCost"), extendConfig({}, controller.args[2], "lblTotalCompetitorCost"));
        var lblTotalSavingsLabel = new voltmx.ui.Label(extendConfig({
            "height": "15dp",
            "id": "lblTotalSavingsLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLightBlue70",
            "text": "TOTAL SAVINGS",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalSavingsLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalSavingsLabel"), extendConfig({}, controller.args[2], "lblTotalSavingsLabel"));
        var lblTotalSavings = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lblTotalSavings",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblVioletBold150",
            "text": "$199K",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalSavings"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalSavings"), extendConfig({}, controller.args[2], "lblTotalSavings"));
        var lblTotalSavedLabel = new voltmx.ui.Label(extendConfig({
            "height": "15dp",
            "id": "lblTotalSavedLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLightBlue70",
            "text": "TOTAL SAVED (%)",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalSavedLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalSavedLabel"), extendConfig({}, controller.args[2], "lblTotalSavedLabel"));
        var lblTotalSaved = new voltmx.ui.Label(extendConfig({
            "height": "40dp",
            "id": "lblTotalSaved",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblVioletBold150",
            "text": "$199K",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTotalSaved"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTotalSaved"), extendConfig({}, controller.args[2], "lblTotalSaved"));
        var lblSavingsPerAppLabel = new voltmx.ui.Label(extendConfig({
            "height": "15dp",
            "id": "lblSavingsPerAppLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblLightBlue70",
            "text": "SAVINGS PER APP",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSavingsPerAppLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSavingsPerAppLabel"), extendConfig({}, controller.args[2], "lblSavingsPerAppLabel"));
        var lblSavingsPerApp = new voltmx.ui.Label(extendConfig({
            "bottom": 20,
            "height": "40dp",
            "id": "lblSavingsPerApp",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblVioletBold150",
            "text": "$199K",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSavingsPerApp"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSavingsPerApp"), extendConfig({}, controller.args[2], "lblSavingsPerApp"));
        ComparisonBox.add(lblYear, lblTotalMXGoCostLabel, lblTotalMXGoCost, lblTotalCompetitorCostLabel, lblTotalCompetitorCost, lblTotalSavingsLabel, lblTotalSavings, lblTotalSavedLabel, lblTotalSaved, lblSavingsPerAppLabel, lblSavingsPerApp);
        ComparisonBox.compInstData = {}
        return ComparisonBox;
    }
})
;
define("com/hcl/demo/tcocalculator/ComparisonLine/userComparisonLineController", [],function() {
    return {};
});
define("com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLineControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLineController", ["com/hcl/demo/tcocalculator/ComparisonLine/userComparisonLineController", "com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLineControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/ComparisonLine/userComparisonLineController");
    var actions = require("com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLineControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLine',[],function() {
    return function(controller) {
        var ComparisonLine = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "ComparisonLine",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ComparisonLine"), extendConfig({}, controller.args[1], "ComparisonLine"), extendConfig({}, controller.args[2], "ComparisonLine"));
        ComparisonLine.setDefaultUnit(voltmx.flex.DP);
        var lblCircle = new voltmx.ui.Label(extendConfig({
            "height": "5dp",
            "id": "lblCircle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblIconWhite10",
            "text": "",
            "top": "5dp",
            "width": "3%",
            "zIndex": 1
        }, controller.args[0], "lblCircle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCircle"), extendConfig({}, controller.args[2], "lblCircle"));
        var lblLabel = new voltmx.ui.Label(extendConfig({
            "id": "lblLabel",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhite70",
            "text": "Less than 10 Pageshdh df lkh df lh df lh dfkh jh djfh jh dfjkh jkdfh jkh dkjf ",
            "top": "0dp",
            "width": "85%",
            "zIndex": 1
        }, controller.args[0], "lblLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel"), extendConfig({}, controller.args[2], "lblLabel"));
        ComparisonLine.add(lblCircle, lblLabel);
        ComparisonLine.compInstData = {}
        return ComparisonLine;
    }
})
;
define("com/hcl/demo/tcocalculator/ContactInfo/userContactInfoController", [],function() {
    const SKIN_ENABLE = 'sknLblBlack70';
    const SKIN_DISABLE = 'sknLblDarkGrey70';
    return {
        constructor(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.flxClose.onClick = () => this.view.isVisible = false;
                    this.view.flxSeeFullReport.onClick = () => {
                        if (this.view.lblSeeFullReport.skin === SKIN_ENABLE) {
                            this.view.isVisible = false;
                            this.onClickOk();
                        }
                    };
                    this.view.fieldEmail.onTextChange = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.view.fieldFirstName.onTextChange = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.view.fieldLastName.onTextChange = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.view.fieldCompany.onTextChange = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.view.checkBoxUS.onSelect = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.view.checkBoxPolicy.onSelect = () => this.view.lblSeeFullReport.skin = this.check() ? SKIN_ENABLE : SKIN_DISABLE;
                    this.initDone = true;
                }
            };
        },
        initGettersSetters() {},
        onClickOk() {},
        show() {
            //         this.view.lblSeeFullReport.skin = SKIN_DISABLE;
            //         this.view.fieldEmail.text = '';
            //         this.view.fieldFirstName.text = '';
            //         this.view.fieldLastName.text = '';
            //         this.view.fieldCompany.text = '';
            //         this.view.checkBoxUS.selected = false;
            //         this.view.checkBoxPolicy.selected = false;
            this.view.isVisible = true;
        },
        check() {
            return this.view.fieldEmail.text && this.view.fieldFirstName.text && this.view.fieldLastName.text && this.view.fieldCompany.text && this.view.checkBoxUS.selected && this.view.checkBoxPolicy.selected;
        }
    };
});
define("com/hcl/demo/tcocalculator/ContactInfo/ContactInfoControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/ContactInfo/ContactInfoController", ["com/hcl/demo/tcocalculator/ContactInfo/userContactInfoController", "com/hcl/demo/tcocalculator/ContactInfo/ContactInfoControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/ContactInfo/userContactInfoController");
    var actions = require("com/hcl/demo/tcocalculator/ContactInfo/ContactInfoControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/ContactInfo/ContactInfo',[],function() {
    return function(controller) {
        var ContactInfo = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "ContactInfo",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ContactInfo"), extendConfig({}, controller.args[1], "ContactInfo"), extendConfig({}, controller.args[2], "ContactInfo"));
        ContactInfo.setDefaultUnit(voltmx.flex.DP);
        var flxBackground = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxBackground",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBackground",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxBackground"), extendConfig({}, controller.args[1], "flxBackground"), extendConfig({}, controller.args[2], "flxBackground"));
        flxBackground.setDefaultUnit(voltmx.flex.DP);
        flxBackground.add();
        var flxPopup = new voltmx.ui.FlexContainer(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "height": "550dp",
            "id": "flxPopup",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "328dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0aa8ce746ee984e",
            "top": "224dp",
            "width": "580dp",
            "zIndex": 1
        }, controller.args[0], "flxPopup"), extendConfig({}, controller.args[1], "flxPopup"), extendConfig({}, controller.args[2], "flxPopup"));
        flxPopup.setDefaultUnit(voltmx.flex.DP);
        var flxRow1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "40dp",
            "id": "flxRow1",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "520dp",
            "zIndex": 1
        }, controller.args[0], "flxRow1"), extendConfig({}, controller.args[1], "flxRow1"), extendConfig({}, controller.args[2], "flxRow1"));
        flxRow1.setDefaultUnit(voltmx.flex.DP);
        var flxRow1Left = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxRow1Left",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "440dp",
            "zIndex": 1
        }, controller.args[0], "flxRow1Left"), extendConfig({}, controller.args[1], "flxRow1Left"), extendConfig({}, controller.args[2], "flxRow1Left"));
        flxRow1Left.setDefaultUnit(voltmx.flex.DP);
        var lblContactnformation = new voltmx.ui.Label(extendConfig({
            "id": "lblContactnformation",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBlackBold100",
            "text": "Contact Information",
            "top": "3dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblContactnformation"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblContactnformation"), extendConfig({}, controller.args[2], "lblContactnformation"));
        var lblPleaseComplete = new voltmx.ui.Label(extendConfig({
            "bottom": 3,
            "id": "lblPleaseComplete",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblGrey70",
            "text": "Please complete the form below to see your results",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPleaseComplete"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPleaseComplete"), extendConfig({}, controller.args[2], "lblPleaseComplete"));
        flxRow1Left.add(lblContactnformation, lblPleaseComplete);
        var flxClose = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxClose",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "right": 0,
            "skin": "slFbox",
            "top": "0dp",
            "width": "40dp",
            "zIndex": 1
        }, controller.args[0], "flxClose"), extendConfig({}, controller.args[1], "flxClose"), extendConfig({}, controller.args[2], "flxClose"));
        flxClose.setDefaultUnit(voltmx.flex.DP);
        var lblClose = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblClose",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblIconBlack250",
            "text": "d",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblClose"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblClose"), extendConfig({}, controller.args[2], "lblClose"));
        flxClose.add(lblClose);
        flxRow1.add(flxRow1Left, flxClose);
        var fieldEmail = new com.hcl.demo.tcocalculator.ContactInfoEditField(extendConfig({
            "centerX": "50%",
            "height": "50dp",
            "id": "fieldEmail",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "520dp",
            "zIndex": 1,
            "overrides": {
                "txtField": {
                    "placeholder": "   "
                },
                "ContactInfoEditField": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "fieldEmail"), extendConfig({
            "overrides": {}
        }, controller.args[1], "fieldEmail"), extendConfig({
            "overrides": {}
        }, controller.args[2], "fieldEmail"));
        var flxName = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "50dp",
            "id": "flxName",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "520dp"
        }, controller.args[0], "flxName"), extendConfig({}, controller.args[1], "flxName"), extendConfig({}, controller.args[2], "flxName"));
        flxName.setDefaultUnit(voltmx.flex.DP);
        var fieldFirstName = new com.hcl.demo.tcocalculator.ContactInfoEditField(extendConfig({
            "height": "50dp",
            "id": "fieldFirstName",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "255dp",
            "zIndex": 1,
            "overrides": {
                "lblLabel": {
                    "text": "First Name"
                },
                "txtField": {
                    "placeholder": "   "
                },
                "ContactInfoEditField": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "fieldFirstName"), extendConfig({
            "overrides": {}
        }, controller.args[1], "fieldFirstName"), extendConfig({
            "overrides": {}
        }, controller.args[2], "fieldFirstName"));
        var fieldLastName = new com.hcl.demo.tcocalculator.ContactInfoEditField(extendConfig({
            "height": "50dp",
            "id": "fieldLastName",
            "isVisible": true,
            "left": "10dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "255dp",
            "zIndex": 1,
            "overrides": {
                "lblLabel": {
                    "text": "Last Name"
                },
                "txtField": {
                    "placeholder": "   "
                },
                "ContactInfoEditField": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "fieldLastName"), extendConfig({
            "overrides": {}
        }, controller.args[1], "fieldLastName"), extendConfig({
            "overrides": {}
        }, controller.args[2], "fieldLastName"));
        flxName.add(fieldFirstName, fieldLastName);
        var fieldCompany = new com.hcl.demo.tcocalculator.ContactInfoEditField(extendConfig({
            "centerX": "50%",
            "height": "50dp",
            "id": "fieldCompany",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "520dp",
            "zIndex": 1,
            "overrides": {
                "lblLabel": {
                    "text": "Company"
                },
                "txtField": {
                    "placeholder": "   "
                },
                "ContactInfoEditField": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "fieldCompany"), extendConfig({
            "overrides": {}
        }, controller.args[1], "fieldCompany"), extendConfig({
            "overrides": {}
        }, controller.args[2], "fieldCompany"));
        var checkBoxUS = new com.hcl.demo.tcocalculator.CheckBox(extendConfig({
            "centerX": "50%",
            "height": "30dp",
            "id": "checkBoxUS",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "520dp",
            "zIndex": 1,
            "overrides": {
                "lblText": {
                    "text": "I am not a U.S. Federal Government employee or agency, nor am I submitting on behalf of one."
                },
                "CheckBox": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "checkBoxUS"), extendConfig({
            "overrides": {}
        }, controller.args[1], "checkBoxUS"), extendConfig({
            "overrides": {}
        }, controller.args[2], "checkBoxUS"));
        checkBoxUS.selected = false;
        var lblUS = new voltmx.ui.Label(extendConfig({
            "id": "lblUS",
            "isVisible": true,
            "left": "60dp",
            "skin": "sknMediumBlack70",
            "text": "HCL provides software & services to the U.S. Federal Government trough its partner ImmixGroup, Inc.",
            "top": "1dp",
            "width": "470dp",
            "zIndex": 1
        }, controller.args[0], "lblUS"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUS"), extendConfig({}, controller.args[2], "lblUS"));
        var checkBoxPolicy = new com.hcl.demo.tcocalculator.CheckBox(extendConfig({
            "centerX": "50%",
            "height": "30dp",
            "id": "checkBoxPolicy",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "520dp",
            "zIndex": 1,
            "overrides": {
                "lblText": {
                    "text": "I agree to HCL's Private Policy Statement."
                },
                "CheckBox": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "checkBoxPolicy"), extendConfig({
            "overrides": {}
        }, controller.args[1], "checkBoxPolicy"), extendConfig({
            "overrides": {}
        }, controller.args[2], "checkBoxPolicy"));
        checkBoxPolicy.selected = false;
        var lblPolicy = new voltmx.ui.Label(extendConfig({
            "id": "lblPolicy",
            "isVisible": true,
            "left": "60dp",
            "skin": "sknMediumBlack70",
            "text": "HCL is collecting this information for its legitimate interests and you acknowledge that we may contact you about products or services that could be of interest to you. You may unsubscribe from our emails at any time.",
            "top": "1dp",
            "width": "490dp",
            "zIndex": 1
        }, controller.args[0], "lblPolicy"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPolicy"), extendConfig({}, controller.args[2], "lblPolicy"));
        var flxSeeFullReport = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "50dp",
            "id": "flxSeeFullReport",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknFlxVioletFull",
            "top": "40dp",
            "width": "520dp",
            "zIndex": 1
        }, controller.args[0], "flxSeeFullReport"), extendConfig({}, controller.args[1], "flxSeeFullReport"), extendConfig({}, controller.args[2], "flxSeeFullReport"));
        flxSeeFullReport.setDefaultUnit(voltmx.flex.DP);
        var lblSeeFullReport = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblSeeFullReport",
            "isVisible": true,
            "skin": "sknLblDarkGrey70",
            "text": "SEE FULL REPORT",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSeeFullReport"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSeeFullReport"), extendConfig({}, controller.args[2], "lblSeeFullReport"));
        flxSeeFullReport.add(lblSeeFullReport);
        flxPopup.add(flxRow1, fieldEmail, flxName, fieldCompany, checkBoxUS, lblUS, checkBoxPolicy, lblPolicy, flxSeeFullReport);
        ContactInfo.add(flxBackground, flxPopup);
        ContactInfo.breakpointResetData = {};
        ContactInfo.breakpointData = {
            maxBreakpointWidth: 1366,
            "640": {
                "flxPopup": {
                    "height": {
                        "type": "ref",
                        "value": voltmx.flex.USE_PREFFERED_SIZE
                    },
                    "segmentProps": []
                },
                "flxRow1": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "fieldEmail": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "flxName": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "fieldCompany": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "checkBoxUS": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "lblUS": {
                    "centerX": {
                        "type": "string",
                        "value": "50%"
                    },
                    "left": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "top": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "80%"
                    },
                    "segmentProps": []
                },
                "checkBoxPolicy": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                },
                "lblPolicy": {
                    "centerX": {
                        "type": "string",
                        "value": "50%"
                    },
                    "left": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "top": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "80%"
                    },
                    "segmentProps": []
                },
                "flxSeeFullReport": {
                    "width": {
                        "type": "string",
                        "value": "90%"
                    },
                    "segmentProps": []
                }
            }
        }
        ContactInfo.compInstData = {
            "fieldEmail": {
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            },
            "fieldFirstName": {
                "label": "First Name",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "fieldLastName": {
                "label": "Last Name",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            },
            "fieldCompany": {
                "label": "Company",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            },
            "checkBoxUS": {
                "text": "I am not a U.S. Federal Government employee or agency, nor am I submitting on behalf of one.",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            },
            "checkBoxPolicy": {
                "text": "I agree to HCL's Private Policy Statement.",
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            }
        }
        return ContactInfo;
    }
})
;
define('com/hcl/demo/tcocalculator/ContactInfo/ContactInfoConfig',[],function() {
    return {
        "properties": [],
        "apis": ["show"],
        "events": ["onClickOk"]
    }
});

define("com/hcl/demo/tcocalculator/ContactInfoEditField/userContactInfoEditFieldController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldController", ["com/hcl/demo/tcocalculator/ContactInfoEditField/userContactInfoEditFieldController", "com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/ContactInfoEditField/userContactInfoEditFieldController");
    var actions = require("com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "label", function(val) {
            this.view.lblLabel.text = val;
        });
        defineGetter(this, "label", function() {
            return this.view.lblLabel.text;
        });
        defineSetter(this, "placeholder", function(val) {
            this.view.txtField.placeholder = val;
        });
        defineGetter(this, "placeholder", function() {
            return this.view.txtField.placeholder;
        });
        defineSetter(this, "text", function(val) {
            this.view.txtField.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.txtField.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditField',[],function() {
    return function(controller) {
        var ContactInfoEditField = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "55dp",
            "id": "ContactInfoEditField",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "ContactInfoEditField"), extendConfig({}, controller.args[1], "ContactInfoEditField"), extendConfig({}, controller.args[2], "ContactInfoEditField"));
        ContactInfoEditField.setDefaultUnit(voltmx.flex.DP);
        var flxLabel = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "15dp",
            "id": "flxLabel",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxLabel"), extendConfig({}, controller.args[1], "flxLabel"), extendConfig({}, controller.args[2], "flxLabel"));
        flxLabel.setDefaultUnit(voltmx.flex.DP);
        var lblLabel = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblBlack70",
            "text": "Email",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel"), extendConfig({}, controller.args[2], "lblLabel"));
        var lblAsterisc = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblAsterisc",
            "isVisible": true,
            "left": "2dp",
            "skin": "sknLblRed70",
            "text": "*",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblAsterisc"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblAsterisc"), extendConfig({}, controller.args[2], "lblAsterisc"));
        flxLabel.add(lblLabel, lblAsterisc);
        var txtField = new voltmx.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerX": "50%",
            "focusSkin": "sknTxtRoundedGrey",
            "height": "32dp",
            "id": "txtField",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "secureTextEntry": false,
            "skin": "sknTxtRoundedGrey",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "top": "3dp",
            "width": "99%",
            "zIndex": 1
        }, controller.args[0], "txtField"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtField"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTxtPlaceholderDesktop"
        }, controller.args[2], "txtField"));
        ContactInfoEditField.add(flxLabel, txtField);
        ContactInfoEditField.compInstData = {}
        return ContactInfoEditField;
    }
})
;
define('com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldConfig',[],function() {
    return {
        "properties": [{
            "name": "label",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "placeholder",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/tcocalculator/DefinitionsLine/userDefinitionsLineController", [],function() {
    return {};
});
define("com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLineControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLineController", ["com/hcl/demo/tcocalculator/DefinitionsLine/userDefinitionsLineController", "com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLineControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/DefinitionsLine/userDefinitionsLineController");
    var actions = require("com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLineControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLine',[],function() {
    return function(controller) {
        var DefinitionsLine = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "DefinitionsLine",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "DefinitionsLine"), extendConfig({}, controller.args[1], "DefinitionsLine"), extendConfig({}, controller.args[2], "DefinitionsLine"));
        DefinitionsLine.setDefaultUnit(voltmx.flex.DP);
        var lblCircle = new voltmx.ui.Label(extendConfig({
            "height": "5dp",
            "id": "lblCircle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblIconWhite10",
            "text": "",
            "top": "5dp",
            "width": "10dp",
            "zIndex": 1
        }, controller.args[0], "lblCircle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCircle"), extendConfig({}, controller.args[2], "lblCircle"));
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "id": "lblTitle",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhiteBold70",
            "text": "title",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblDefinition = new voltmx.ui.Label(extendConfig({
            "id": "lblDefinition",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblWhite70",
            "text": "content",
            "top": "0dp",
            "width": "80%",
            "zIndex": 1
        }, controller.args[0], "lblDefinition"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblDefinition"), extendConfig({}, controller.args[2], "lblDefinition"));
        DefinitionsLine.add(lblCircle, lblTitle, lblDefinition);
        DefinitionsLine.compInstData = {}
        return DefinitionsLine;
    }
})
;
define("com/hcl/demo/tcocalculator/InfoBox/userInfoBoxController", [],function() {
    return {};
});
define("com/hcl/demo/tcocalculator/InfoBox/InfoBoxControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/InfoBox/InfoBoxController", ["com/hcl/demo/tcocalculator/InfoBox/userInfoBoxController", "com/hcl/demo/tcocalculator/InfoBox/InfoBoxControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/InfoBox/userInfoBoxController");
    var actions = require("com/hcl/demo/tcocalculator/InfoBox/InfoBoxControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/InfoBox/InfoBox',[],function() {
    return function(controller) {
        var InfoBox = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "90dp",
            "id": "InfoBox",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "256dp",
            "isModalContainer": false,
            "skin": "sknFlxVioletTransparent",
            "top": "264dp",
            "width": "150dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "InfoBox"), extendConfig({}, controller.args[1], "InfoBox"), extendConfig({}, controller.args[2], "InfoBox"));
        InfoBox.setDefaultUnit(voltmx.flex.DP);
        var lblInfoBoxTitle = new voltmx.ui.Label(extendConfig({
            "id": "lblInfoBoxTitle",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhite100",
            "text": "Simple Apps",
            "top": "10dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblInfoBoxTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblInfoBoxTitle"), extendConfig({}, controller.args[2], "lblInfoBoxTitle"));
        var flxLine1 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "15dp",
            "id": "flxLine1",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "100%"
        }, controller.args[0], "flxLine1"), extendConfig({}, controller.args[1], "flxLine1"), extendConfig({}, controller.args[2], "flxLine1"));
        flxLine1.setDefaultUnit(voltmx.flex.DP);
        var lblCircle1 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblCircle1",
            "isVisible": true,
            "left": "20dp",
            "skin": "sknLblIconWhite10",
            "text": "",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCircle1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCircle1"), extendConfig({}, controller.args[2], "lblCircle1"));
        var lblLabel1 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblLabel1",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhite70",
            "text": "Less than 10 Pages",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblLabel1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel1"), extendConfig({}, controller.args[2], "lblLabel1"));
        flxLine1.add(lblCircle1, lblLabel1);
        var flxLine2 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "15dp",
            "id": "flxLine2",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxLine2"), extendConfig({}, controller.args[1], "flxLine2"), extendConfig({}, controller.args[2], "flxLine2"));
        flxLine2.setDefaultUnit(voltmx.flex.DP);
        var lblCircle2 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblCircle2",
            "isVisible": true,
            "left": "20dp",
            "skin": "sknLblIconWhite10",
            "text": "",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCircle2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCircle2"), extendConfig({}, controller.args[2], "lblCircle2"));
        var lblLabel2 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblLabel2",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhite70",
            "text": "1-5 Workflows",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblLabel2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel2"), extendConfig({}, controller.args[2], "lblLabel2"));
        flxLine2.add(lblCircle2, lblLabel2);
        var flxLine3 = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "15dp",
            "id": "flxLine3",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "flxLine3"), extendConfig({}, controller.args[1], "flxLine3"), extendConfig({}, controller.args[2], "flxLine3"));
        flxLine3.setDefaultUnit(voltmx.flex.DP);
        var lblCircle3 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblCircle3",
            "isVisible": true,
            "left": "20dp",
            "skin": "sknLblIconWhite10",
            "text": "",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCircle3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCircle3"), extendConfig({}, controller.args[2], "lblCircle3"));
        var lblLabel3 = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblLabel3",
            "isVisible": true,
            "left": "10dp",
            "skin": "sknLblWhite70",
            "text": "1-2 Integrations",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblLabel3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel3"), extendConfig({}, controller.args[2], "lblLabel3"));
        flxLine3.add(lblCircle3, lblLabel3);
        InfoBox.add(lblInfoBoxTitle, flxLine1, flxLine2, flxLine3);
        InfoBox.compInstData = {}
        return InfoBox;
    }
})
;
define("com/hcl/demo/tcocalculator/MobileHeader/userMobileHeaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderController", ["com/hcl/demo/tcocalculator/MobileHeader/userMobileHeaderController", "com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/MobileHeader/userMobileHeaderController");
    var actions = require("com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "title", function(val) {
            this.view.lblTitle.text = val;
        });
        defineGetter(this, "title", function() {
            return this.view.lblTitle.text;
        });
        defineSetter(this, "subtitle", function(val) {
            this.view.lblSubtitle.text = val;
        });
        defineGetter(this, "subtitle", function() {
            return this.view.lblSubtitle.text;
        });
        defineSetter(this, "showSubtitle", function(val) {
            this.view.lblSubtitle.isVisible = val;
        });
        defineGetter(this, "showSubtitle", function() {
            return this.view.lblSubtitle.isVisible;
        });
        defineSetter(this, "showButton", function(val) {
            this.view.lblBack.isVisible = val;
        });
        defineGetter(this, "showButton", function() {
            return this.view.lblBack.isVisible;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onClickButton_b702522136ed486c94e78d87f4be652e = function() {
        if (this.onClickButton) {
            this.onClickButton.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/MobileHeader/MobileHeader',[],function() {
    return function(controller) {
        var MobileHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "8%",
            "id": "MobileHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxGradient",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "MobileHeader"), extendConfig({}, controller.args[1], "MobileHeader"), extendConfig({}, controller.args[2], "MobileHeader"));
        MobileHeader.setDefaultUnit(voltmx.flex.DP);
        var lblTitle = new voltmx.ui.Label(extendConfig({
            "height": "50%",
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite120",
            "text": "HCL Volt MX Go",
            "textStyle": {},
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblSubtitle = new voltmx.ui.Label(extendConfig({
            "height": "50%",
            "id": "lblSubtitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite100",
            "text": "Total Cost of Ownership Calculator",
            "textStyle": {},
            "top": "50%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblSubtitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblSubtitle"), extendConfig({}, controller.args[2], "lblSubtitle"));
        var lblBack = new voltmx.ui.Label(extendConfig({
            "height": "50%",
            "id": "lblBack",
            "isVisible": true,
            "left": "0dp",
            "onTouchEnd": controller.AS_onClickButton_b702522136ed486c94e78d87f4be652e,
            "skin": "sknLblIconWhite100",
            "text": "h",
            "textStyle": {},
            "top": "0dp",
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblBack"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBack"), extendConfig({}, controller.args[2], "lblBack"));
        MobileHeader.add(lblTitle, lblSubtitle, lblBack);
        MobileHeader.compInstData = {}
        return MobileHeader;
    }
})
;
define('com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderConfig',[],function() {
    return {
        "properties": [{
            "name": "title",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "subtitle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showSubtitle",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "showButton",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickButton"]
    }
});

define("com/hcl/demo/tcocalculator/SimpleAlert/userSimpleAlertController", [],function() {
    const SKIN_ENABLE = 'sknLblBlack70';
    const SKIN_DISABLE = 'sknLblDarkGrey70';
    return {
        constructor(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.flxClose.onClick = () => this.view.isVisible = false;
                    this.initDone = true;
                }
            };
        },
        initGettersSetters() {},
    };
});
define("com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertController", ["com/hcl/demo/tcocalculator/SimpleAlert/userSimpleAlertController", "com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/SimpleAlert/userSimpleAlertController");
    var actions = require("com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "text", function(val) {
            this.view.lblText.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.lblText.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlert',[],function() {
    return function(controller) {
        var SimpleAlert = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "SimpleAlert",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "SimpleAlert"), extendConfig({}, controller.args[1], "SimpleAlert"), extendConfig({}, controller.args[2], "SimpleAlert"));
        SimpleAlert.setDefaultUnit(voltmx.flex.DP);
        var flxBackground = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxBackground",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBackground",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "flxBackground"), extendConfig({}, controller.args[1], "flxBackground"), extendConfig({}, controller.args[2], "flxBackground"));
        flxBackground.setDefaultUnit(voltmx.flex.DP);
        flxBackground.add();
        var flxPopup = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": true,
            "id": "flxPopup",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "isModalContainer": false,
            "skin": "CopyslFbox0aa8ce746ee984e",
            "width": "300dp",
            "zIndex": 1
        }, controller.args[0], "flxPopup"), extendConfig({}, controller.args[1], "flxPopup"), extendConfig({}, controller.args[2], "flxPopup"));
        flxPopup.setDefaultUnit(voltmx.flex.DP);
        var lblText = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblText",
            "isVisible": true,
            "left": "60dp",
            "skin": "sknMediumBlack70",
            "text": "This is the alert Text",
            "top": "30dp",
            "width": "280dp",
            "zIndex": 1
        }, controller.args[0], "lblText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblText"), extendConfig({}, controller.args[2], "lblText"));
        var flxClose = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": "20dp",
            "centerX": "50%",
            "clipBounds": true,
            "height": "50dp",
            "id": "flxClose",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknFlxVioletFull",
            "top": "20dp",
            "width": "90%",
            "zIndex": 1
        }, controller.args[0], "flxClose"), extendConfig({}, controller.args[1], "flxClose"), extendConfig({}, controller.args[2], "flxClose"));
        flxClose.setDefaultUnit(voltmx.flex.DP);
        var lblClose = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "lblClose",
            "isVisible": true,
            "skin": "sknLblBlack70",
            "text": "CLOSE",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblClose"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblClose"), extendConfig({}, controller.args[2], "lblClose"));
        flxClose.add(lblClose);
        flxPopup.add(lblText, flxClose);
        SimpleAlert.add(flxBackground, flxPopup);
        SimpleAlert.compInstData = {}
        return SimpleAlert;
    }
})
;
define('com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertConfig',[],function() {
    return {
        "properties": [{
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/tcocalculator/SimpleHeader/userSimpleHeaderController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderController", ["com/hcl/demo/tcocalculator/SimpleHeader/userSimpleHeaderController", "com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/SimpleHeader/userSimpleHeaderController");
    var actions = require("com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeader',[],function() {
    return function(controller) {
        var SimpleHeader = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "5%",
            "id": "SimpleHeader",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxBlack",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "SimpleHeader"), extendConfig({}, controller.args[1], "SimpleHeader"), extendConfig({}, controller.args[2], "SimpleHeader"));
        SimpleHeader.setDefaultUnit(voltmx.flex.DP);
        var imgLogo = new voltmx.ui.Image2(extendConfig({
            "centerY": "50%",
            "height": "90%",
            "id": "imgLogo",
            "isVisible": true,
            "left": "5dp",
            "skin": "slImage",
            "src": "voltmx_48.png",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "imgLogo"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLogo"), extendConfig({}, controller.args[2], "imgLogo"));
        var lblVoltMX = new voltmx.ui.Label(extendConfig({
            "height": "100%",
            "id": "lblVoltMX",
            "isVisible": true,
            "left": "5dp",
            "skin": "sknLblWhite120",
            "text": "HCL Volt MX",
            "top": "0dp",
            "width": "200dp",
            "zIndex": 1
        }, controller.args[0], "lblVoltMX"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblVoltMX"), extendConfig({}, controller.args[2], "lblVoltMX"));
        SimpleHeader.add(imgLogo, lblVoltMX);
        SimpleHeader.compInstData = {}
        return SimpleHeader;
    }
})
;
define('com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderConfig',[],function() {
    return {
        "properties": [],
        "apis": [],
        "events": []
    }
});

define("com/hcl/demo/tcocalculator/StandardEditField/userStandardEditFieldController", [],function() {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {},
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {}
    };
});
define("com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldController", ["com/hcl/demo/tcocalculator/StandardEditField/userStandardEditFieldController", "com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/StandardEditField/userStandardEditFieldController");
    var actions = require("com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "label", function(val) {
            this.view.lblLabel.text = val;
        });
        defineGetter(this, "label", function() {
            return this.view.lblLabel.text;
        });
        defineSetter(this, "placeholder", function(val) {
            this.view.txtField.placeholder = val;
        });
        defineGetter(this, "placeholder", function() {
            return this.view.txtField.placeholder;
        });
        defineSetter(this, "text", function(val) {
            this.view.txtField.text = val;
        });
        defineGetter(this, "text", function() {
            return this.view.txtField.text;
        });
        defineSetter(this, "textInputMode", function(val) {
            this.view.txtField.textInputMode = val;
        });
        defineGetter(this, "textInputMode", function() {
            return this.view.txtField.textInputMode;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    controller.AS_onTextChange_db45bce65d2140169d7918edc52969c1 = function() {
        if (this.onTextChange) {
            this.onTextChange.apply(this, arguments);
        }
    }
    return controller;
});

define('com/hcl/demo/tcocalculator/StandardEditField/StandardEditField',[],function() {
    return function(controller) {
        var StandardEditField = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "StandardEditField",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "StandardEditField"), extendConfig({}, controller.args[1], "StandardEditField"), extendConfig({}, controller.args[2], "StandardEditField"));
        StandardEditField.setDefaultUnit(voltmx.flex.DP);
        var lblLabel = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "height": "27dp",
            "id": "lblLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite70",
            "text": "How many applications would you like to migrate? *",
            "top": "0dp",
            "width": "99%",
            "zIndex": 1
        }, controller.args[0], "lblLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel"), extendConfig({}, controller.args[2], "lblLabel"));
        var txtField = new voltmx.ui.TextBox2(extendConfig({
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerX": "50%",
            "focusSkin": "sknTxtRounded",
            "height": "38dp",
            "id": "txtField",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "0dp",
            "onTextChange": controller.AS_onTextChange_db45bce65d2140169d7918edc52969c1,
            "secureTextEntry": false,
            "skin": "sknTxtRounded",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
            "top": "3dp",
            "width": "99%",
            "zIndex": 1,
            "isSensitiveText": false
        }, controller.args[0], "txtField"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [3, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtField"), extendConfig({
            "autoCorrect": false,
            "placeholderSkin": "sknTxtPlaceholderDesktop"
        }, controller.args[2], "txtField"));
        StandardEditField.add(lblLabel, txtField);
        StandardEditField.compInstData = {}
        return StandardEditField;
    }
})
;
define('com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldConfig',[],function() {
    return {
        "properties": [{
            "name": "label",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "placeholder",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "textInputMode",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onTextChange"]
    }
});

define("com/hcl/demo/tcocalculator/StandardNumPerc/userStandardNumPercController", [],function() {
    return {
        constructor(baseConfig, layoutConfig, pspConfig) {
            this.view.preShow = () => {
                if (!this.initDone) {
                    this.view.flxLeft.onClick = () => {
                        this.selection = 'num';
                        this.onSelect('num');
                    };
                    this.view.flxRight.onClick = () => {
                        this.selection = 'perc';
                        this.onSelect('perc');
                    };
                }
            };
        },
        initGettersSetters() {
            defineGetter(this, 'selection', () => {
                return this._selection;
            });
            defineSetter(this, 'selection', value => {
                this._selection = value;
                if (value === 'num') {
                    this.view.lblCheckedLeft.isVisible = true;
                    this.view.lblUncheckedLeft.isVisible = false;
                    this.view.lblCheckedRight.isVisible = false;
                    this.view.lblUncheckedRight.isVisible = true;
                } else if (value === 'perc') {
                    this.view.lblCheckedLeft.isVisible = false;
                    this.view.lblUncheckedLeft.isVisible = true;
                    this.view.lblCheckedRight.isVisible = true;
                    this.view.lblUncheckedRight.isVisible = false;
                } else {
                    this.view.lblCheckedLeft.isVisible = false;
                    this.view.lblUncheckedLeft.isVisible = true;
                    this.view.lblCheckedRight.isVisible = false;
                    this.view.lblUncheckedRight.isVisible = true;
                }
            });
        },
        onSelect() {}
    };
});
define("com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercController", ["com/hcl/demo/tcocalculator/StandardNumPerc/userStandardNumPercController", "com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercControllerActions"], function() {
    var controller = require("com/hcl/demo/tcocalculator/StandardNumPerc/userStandardNumPercController");
    var actions = require("com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "label", function(val) {
            this.view.lblLabel.text = val;
        });
        defineGetter(this, "label", function() {
            return this.view.lblLabel.text;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPerc',[],function() {
    return function(controller) {
        var StandardNumPerc = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "isMaster": true,
            "id": "StandardNumPerc",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "CopyslFbox0b658b687daf345",
            "top": "0dp",
            "width": "300dp",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, controller.args[0], "StandardNumPerc"), extendConfig({}, controller.args[1], "StandardNumPerc"), extendConfig({}, controller.args[2], "StandardNumPerc"));
        StandardNumPerc.setDefaultUnit(voltmx.flex.DP);
        var lblLabel = new voltmx.ui.Label(extendConfig({
            "centerX": "50%",
            "id": "lblLabel",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite70",
            "text": "How many of thse apps would you categorize as simple, moderate and complex?  *",
            "top": "0dp",
            "width": "99%",
            "zIndex": 1
        }, controller.args[0], "lblLabel"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblLabel"), extendConfig({}, controller.args[2], "lblLabel"));
        var flxRadio = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "bottom": "10dp",
            "centerX": "50%",
            "clipBounds": true,
            "height": "30dp",
            "id": "flxRadio",
            "isVisible": true,
            "layoutType": voltmx.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "10dp",
            "width": "99%",
            "zIndex": 1
        }, controller.args[0], "flxRadio"), extendConfig({}, controller.args[1], "flxRadio"), extendConfig({}, controller.args[2], "flxRadio"));
        flxRadio.setDefaultUnit(voltmx.flex.DP);
        var flxLeft = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxLeft",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "flxLeft"), extendConfig({}, controller.args[1], "flxLeft"), extendConfig({}, controller.args[2], "flxLeft"));
        flxLeft.setDefaultUnit(voltmx.flex.DP);
        var lblCheckedLeft = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblCheckedLeft",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "f",
            "textStyle": {},
            "top": "0dp",
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblCheckedLeft"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCheckedLeft"), extendConfig({}, controller.args[2], "lblCheckedLeft"));
        var lblUncheckedLeft = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblUncheckedLeft",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "e",
            "textStyle": {},
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblUncheckedLeft"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUncheckedLeft"), extendConfig({}, controller.args[2], "lblUncheckedLeft"));
        flxLeft.add(lblCheckedLeft, lblUncheckedLeft);
        var lblNumber = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblNumber",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite70",
            "text": "Number",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblNumber"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblNumber"), extendConfig({}, controller.args[2], "lblNumber"));
        var flxRight = new voltmx.ui.FlexContainer(extendConfig({
            "autogrowMode": voltmx.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "30dp",
            "id": "flxRight",
            "isVisible": true,
            "layoutType": voltmx.flex.FREE_FORM,
            "left": "10dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "flxRight"), extendConfig({}, controller.args[1], "flxRight"), extendConfig({}, controller.args[2], "flxRight"));
        flxRight.setDefaultUnit(voltmx.flex.DP);
        var lblCheckedRight = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblCheckedRight",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "f",
            "textStyle": {},
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblCheckedRight"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCheckedRight"), extendConfig({}, controller.args[2], "lblCheckedRight"));
        var lblUncheckedRight = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "height": "30dp",
            "id": "lblUncheckedRight",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblCheckboxViolet",
            "text": "e",
            "textStyle": {},
            "width": "30dp",
            "zIndex": 1
        }, controller.args[0], "lblUncheckedRight"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUncheckedRight"), extendConfig({}, controller.args[2], "lblUncheckedRight"));
        flxRight.add(lblCheckedRight, lblUncheckedRight);
        var lblPercentage = new voltmx.ui.Label(extendConfig({
            "centerY": "50%",
            "id": "lblPercentage",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknLblWhite70",
            "text": "Percentage",
            "top": "0dp",
            "width": voltmx.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblPercentage"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPercentage"), extendConfig({}, controller.args[2], "lblPercentage"));
        flxRadio.add(flxLeft, lblNumber, flxRight, lblPercentage);
        StandardNumPerc.add(lblLabel, flxRadio);
        StandardNumPerc.compInstData = {}
        return StandardNumPerc;
    }
})
;
define('com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercConfig',[],function() {
    return {
        "properties": [{
            "name": "label",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "selection",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onSelect"]
    }
});

require(['applicationController','com/hcl/demo/tcocalculator/CheckBox/CheckBoxController','com/hcl/demo/tcocalculator/CheckBox/CheckBox','com/hcl/demo/tcocalculator/CheckBox/CheckBoxConfig','com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBoxController','com/hcl/demo/tcocalculator/ComparisonBox/ComparisonBox','com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLineController','com/hcl/demo/tcocalculator/ComparisonLine/ComparisonLine','com/hcl/demo/tcocalculator/ContactInfo/ContactInfoController','com/hcl/demo/tcocalculator/ContactInfo/ContactInfo','com/hcl/demo/tcocalculator/ContactInfo/ContactInfoConfig','com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldController','com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditField','com/hcl/demo/tcocalculator/ContactInfoEditField/ContactInfoEditFieldConfig','com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLineController','com/hcl/demo/tcocalculator/DefinitionsLine/DefinitionsLine','com/hcl/demo/tcocalculator/InfoBox/InfoBoxController','com/hcl/demo/tcocalculator/InfoBox/InfoBox','com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderController','com/hcl/demo/tcocalculator/MobileHeader/MobileHeader','com/hcl/demo/tcocalculator/MobileHeader/MobileHeaderConfig','com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertController','com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlert','com/hcl/demo/tcocalculator/SimpleAlert/SimpleAlertConfig','com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderController','com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeader','com/hcl/demo/tcocalculator/SimpleHeader/SimpleHeaderConfig','com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldController','com/hcl/demo/tcocalculator/StandardEditField/StandardEditField','com/hcl/demo/tcocalculator/StandardEditField/StandardEditFieldConfig','com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercController','com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPerc','com/hcl/demo/tcocalculator/StandardNumPerc/StandardNumPercConfig'], function(){});

define("sparequirefileslist", function(){});

