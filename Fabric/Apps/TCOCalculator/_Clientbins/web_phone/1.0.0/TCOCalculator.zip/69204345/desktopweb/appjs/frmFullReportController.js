define("userfrmFullReportController", {
    onViewCreated() {
        this.view.init = () => {
            this.view.cmpHeader.onTouchEnd = () => new voltmx.mvc.Navigation('frmHome').navigate();
        };
        this.view.preShow = () => {
            const {
                numApps,
                numUsers,
                numSimple,
                numComplex,
                numModerate,
                isPerc = false,
                percSimple = '0',
                percModerate = '0',
                percComplex = '0'
            } = this.navigationContext;
            this.view.lblNumApps.text = numApps + '';
            this.view.lblUsersNumApps.text = numApps + '';
            this.view.lblNumUsers.text = numUsers + '';
            this.view.lblNumSimple.text = numSimple + (isPerc ? '%' : '');
            this.view.lblNumModerate.text = numModerate + (isPerc ? '%' : '');
            this.view.lblNumComplex.text = numComplex + (isPerc ? '%' : '');
            const {
                costMXGoYear1,
                costCompetitorYear1,
                costMXGoYear3,
                costCompetitorYear3,
                costMXGoYear5,
                costCompetitorYear5
            } = tco.calculate(this.navigationContext);
            this.view.year1.setData(costMXGoYear1, costCompetitorYear1, numApps);
            this.view.year3.setData(costMXGoYear3, costCompetitorYear3, numApps);
            this.view.year5.setData(costMXGoYear5, costCompetitorYear5, numApps);
        };
    }
});
define("frmFullReportControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("frmFullReportController", ["userfrmFullReportController", "frmFullReportControllerActions"], function() {
    var controller = require("userfrmFullReportController");
    var controllerActions = ["frmFullReportControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
