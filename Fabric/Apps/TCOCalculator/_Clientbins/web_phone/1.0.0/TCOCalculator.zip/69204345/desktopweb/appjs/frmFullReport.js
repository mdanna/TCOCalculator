define("frmFullReport", function() {
    return function(controller) {
        function addWidgetsfrmFullReport() {
            this.setDefaultUnit(voltmx.flex.DP);
            var cmpHeader = new com.hcl.demo.tcocalculator.SimpleHeader({
                "height": "5%",
                "id": "cmpHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxBlack",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "overrides": {
                    "SimpleHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxMain = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "95%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxMain.setDefaultUnit(voltmx.flex.DP);
            var flxBody = new voltmx.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "maxWidth": "1000dp",
                "pagingEnabled": false,
                "scrollDirection": voltmx.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBody.setDefaultUnit(voltmx.flex.DP);
            var flxTitle = new voltmx.ui.Label({
                "height": "50dp",
                "id": "flxTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhiteBold150",
                "text": "HCL Volt MX Go: Total Cost of Ownership Calculator",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblParagraph1 = new voltmx.ui.Label({
                "id": "lblParagraph1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLightBlue80",
                "text": "Volt MX Go includes unique capabilities not found in solutions from vendors like Mendix, OutSystems and Microsoft. HCL's unmatched combination of technology and expertise will speed up your migration and ensure that your projects will be delivered on time, on budget and without less risk.",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxGradient",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxContent.setDefaultUnit(voltmx.flex.DP);
            var flxRecap = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxRecap",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "20dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxRecap.setDefaultUnit(voltmx.flex.DP);
            var flxRecapLeft = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxRecapLeft",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {}, {});
            flxRecapLeft.setDefaultUnit(voltmx.flex.DP);
            var lblIconApps = new voltmx.ui.Label({
                "height": "100dp",
                "id": "lblIconApps",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblIconViolet500",
                "text": "a",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApps = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxApps",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {});
            flxApps.setDefaultUnit(voltmx.flex.DP);
            var flxAppsTop = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60%",
                "id": "flxAppsTop",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE
            }, {}, {});
            flxAppsTop.setDefaultUnit(voltmx.flex.DP);
            var lblNumApps = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblNumApps",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite180",
                "text": "100",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApps = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblApps",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknLblWhite180",
                "text": "Applications",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAppsTop.add(lblNumApps, lblApps);
            var flxAppsBottom = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40%",
                "id": "flxAppsBottom",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {});
            flxAppsBottom.setDefaultUnit(voltmx.flex.DP);
            var lblNumSimple = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblNumSimple",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLightBlue80",
                "text": "20%",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimple = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblSimple",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblLightBlue80",
                "text": "Simple",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDot1 = new voltmx.ui.Label({
                "height": "60%",
                "id": "lblDot1",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblIconLightBlue10",
                "text": "",
                "top": "5dp",
                "width": "10dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNumModerate = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblNumModerate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLightBlue80",
                "text": "60%",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblModerate = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblModerate",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblLightBlue80",
                "text": "Moderate",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDot2 = new voltmx.ui.Label({
                "height": "60%",
                "id": "lblDot2",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblIconLightBlue10",
                "text": "",
                "top": "5dp",
                "width": "10dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNumComplex = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblNumComplex",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLightBlue80",
                "text": "20%",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblComplex = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblComplex",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblLightBlue80",
                "text": "Complex",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAppsBottom.add(lblNumSimple, lblSimple, lblDot1, lblNumModerate, lblModerate, lblDot2, lblNumComplex, lblComplex);
            flxApps.add(flxAppsTop, flxAppsBottom);
            flxRecapLeft.add(lblIconApps, flxApps);
            var flxRecapRight = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxRecapRight",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {}, {});
            flxRecapRight.setDefaultUnit(voltmx.flex.DP);
            var lblIconUsers = new voltmx.ui.Label({
                "height": "100dp",
                "id": "lblIconUsers",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblIconViolet800",
                "text": "g",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUsers = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxUsers",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {});
            flxUsers.setDefaultUnit(voltmx.flex.DP);
            var flxUsersTop = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60%",
                "id": "flxUsersTop",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE
            }, {}, {});
            flxUsersTop.setDefaultUnit(voltmx.flex.DP);
            var lblNumUsers = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblNumUsers",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite180",
                "text": "100",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsers = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblUsers",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknLblWhite180",
                "text": "Users",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUsersTop.add(lblNumUsers, lblUsers);
            var flxUsersBottom = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40%",
                "id": "flxUsersBottom",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {});
            flxUsersBottom.setDefaultUnit(voltmx.flex.DP);
            var lblUsersAcross = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblUsersAcross",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblLightBlue80",
                "text": "Across all",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsersNumApps = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblUsersNumApps",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblLightBlue80",
                "text": "100",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsersApplications = new voltmx.ui.Label({
                "height": "100%",
                "id": "lblUsersApplications",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblLightBlue80",
                "text": "Applications",
                "top": "0dp",
                "width": voltmx.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUsersBottom.add(lblUsersAcross, lblUsersNumApps, lblUsersApplications);
            flxUsers.add(flxUsersTop, flxUsersBottom);
            flxRecapRight.add(lblIconUsers, flxUsers);
            flxRecap.add(flxRecapLeft, flxRecapRight);
            var lblSeeTheFollowing = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "60dp",
                "id": "lblSeeTheFollowing",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite90",
                "text": "See the following cost comparison to see why Volt MX Go makes the most business and technical sense for your migration.",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxComparisons = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "455dp",
                "id": "flxComparisons",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxComparisons.setDefaultUnit(voltmx.flex.DP);
            var year1 = new com.hcl.demo.tcocalculator.ComparisonBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "425dp",
                "id": "year1",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "overrides": {}
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var year3 = new com.hcl.demo.tcocalculator.ComparisonBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "425dp",
                "id": "year3",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "5%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "overrides": {
                    "ComparisonBox": {
                        "left": "5%"
                    },
                    "lblYear": {
                        "text": "Year 3"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var year5 = new com.hcl.demo.tcocalculator.ComparisonBox({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "height": "425dp",
                "id": "year5",
                "isVisible": true,
                "layoutType": voltmx.flex.FLOW_VERTICAL,
                "left": "5%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxVioletTransparent",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "overrides": {
                    "ComparisonBox": {
                        "left": "5%"
                    },
                    "lblYear": {
                        "text": "Year 5"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxComparisons.add(year1, year3, year5);
            flxContent.add(flxRecap, lblSeeTheFollowing, flxComparisons);
            var lblWillReachOut = new voltmx.ui.Label({
                "centerX": "50%",
                "height": "60dp",
                "id": "lblWillReachOut",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblWhite120",
                "text": "A Volt MX representative will reach out to provide a personalized analysis of your report.",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContactMe = new voltmx.ui.FlexContainer({
                "autogrowMode": voltmx.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxContactMe",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxVioletFull",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {}, {});
            flxContactMe.setDefaultUnit(voltmx.flex.DP);
            var lblContactMe = new voltmx.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblContactMe",
                "isVisible": true,
                "skin": "sknLblBlack70",
                "text": "CONTACT ME",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactMe.add(lblContactMe);
            flxBody.add(flxTitle, lblParagraph1, flxContent, lblWillReachOut, flxContactMe);
            flxMain.add(flxBody);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxBody": {
                        "width": {
                            "type": "string",
                            "value": "1000dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "cmpHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "year3": {
                    "left": "5%"
                },
                "year3.lblYear": {
                    "text": "Year 3"
                },
                "year5": {
                    "left": "5%"
                },
                "year5.lblYear": {
                    "text": "Year 5"
                }
            }
            this.add(cmpHeader, flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmFullReport,
            "enabledForIdleTimeout": false,
            "id": "frmFullReport",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGradient",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});